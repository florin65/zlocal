#ifndef VIFM_TESTS__BMARKS__UTILS_H__
#define VIFM_TESTS__BMARKS__UTILS_H__

const char * get_tags(const char path[]);

#endif /* VIFM_TESTS__BMARKS__UTILS_H__ */

/* vim: set tabstop=2 softtabstop=2 shiftwidth=2 noexpandtab cinoptions-=(0 : */
/* vim: set cinoptions+=t0 filetype=c : */
