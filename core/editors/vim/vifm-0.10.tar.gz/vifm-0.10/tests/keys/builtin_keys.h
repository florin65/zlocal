#ifndef VIFM_TESTS__KEYS__BUILTIN_KEYS_H__
#define VIFM_TESTS__KEYS__BUILTIN_KEYS_H__

void init_builtin_keys(void);

#endif /* VIFM_TESTS__KEYS__BUILTIN_KEYS_H__ */

/* vim: set tabstop=2 softtabstop=2 shiftwidth=2 noexpandtab cinoptions-=(0 : */
/* vim: set cinoptions+=t0 filetype=c : */
