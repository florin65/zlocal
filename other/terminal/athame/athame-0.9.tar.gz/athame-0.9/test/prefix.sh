#The q\b is for bypassing zsh's newuser script
qunset HISTFILE
