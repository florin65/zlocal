echo "basic test" > out1
