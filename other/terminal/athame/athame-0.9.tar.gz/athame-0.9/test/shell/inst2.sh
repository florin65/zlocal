echo "tab test" > out2_extended
touch out2_exxtended
#This will fail on readline without the last_tab code
mv out2_		t	 out2
rm out2_exxtended
