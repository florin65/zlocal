# Test for flaky tab failures
rm -rf 3*
echo b > 3ob
echo g > 3og
echo 'g' >> 3	g
echo 'g' >> 3	g
echo g >> 3	g
echo g >> 3	g
echo g >> 3	g
echo 'g' >> 3	g
echo 'g' >> 3	g
echo 'g' >> 3	g
echo 'g' >> 3	g
rm 3	b
mv 3	 out3
