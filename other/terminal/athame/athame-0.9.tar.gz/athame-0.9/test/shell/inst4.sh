# Test history
rm -rf out4
echo "a" >> out4
echo "b" >> out4
[A
echo "1" >> out4
echo "2" >> out4
echo "3" >> out4
[A[A
[A
