echo "basic xestbrtA" > out1
echo "basic xest" >> out14brt
