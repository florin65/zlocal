:set nocompatible
:inoremap kj <ESC>
iecho "test 2kj2h~b~A" > out2
