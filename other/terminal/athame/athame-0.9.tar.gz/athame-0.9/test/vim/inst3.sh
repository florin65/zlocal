echo 'vim'
echo 'is awesome' > out3
kf'vkf'c 
