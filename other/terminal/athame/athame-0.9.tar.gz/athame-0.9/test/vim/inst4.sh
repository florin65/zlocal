echo "test 4hlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlhlA" >> out4
